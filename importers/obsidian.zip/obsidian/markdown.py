from __future__ import annotations

import re
from typing import Any

HEADING_RE = re.compile(r"^(#{1,6})\s+(.+?)\s*$")
PROPERTY_RE = re.compile(r"^#([A-Za-z_][A-Za-z0-9_]*)\s*:\s*(.*?)\s*$")
WIKILINK_RE = re.compile(r"\[\[([^\]]+)\]\]")
RUBY_RE = re.compile(r"\{([^|{}]+)\|([^{}]+)\}")
INLINE_TAG_RE = re.compile(r"(?<![\w/])#([A-Za-z0-9_\-/\u3040-\u30ff\u3400-\u9fff]+)")
FRONTMATTER_RE = re.compile(r"\A---\s*\n(.*?)\n---\s*(?:\n|$)", re.DOTALL)


def strip_ruby(text: str) -> str:
    return RUBY_RE.sub(lambda m: m.group(1), text)


def extract_ruby(text: str) -> list[dict[str, str]]:
    result: list[dict[str, str]] = []
    for surface, raw_reading in RUBY_RE.findall(text):
        reading = "".join(part.strip() for part in raw_reading.split("|") if part.strip())
        result.append({
            "surface": surface,
            "reading": reading,
            "raw": raw_reading,
        })
    return result


def extract_wikilinks(text: str) -> list[dict[str, str]]:
    seen: set[tuple[str, str]] = set()
    result: list[dict[str, str]] = []

    for raw in WIKILINK_RE.findall(text):
        parts = raw.split("|", 1)
        target = parts[0].strip()
        alias = parts[1].strip() if len(parts) == 2 else ""
        key = (target, alias)
        if target and key not in seen:
            seen.add(key)
            result.append({"target": target, "alias": alias})

    return result


def parse_frontmatter(text: str) -> tuple[dict[str, Any], str]:
    """
    Lightweight YAML-frontmatter parser supporting the common Obsidian forms
    used by this project. No third-party dependency is required.
    """
    match = FRONTMATTER_RE.match(text)
    if not match:
        return {}, text

    raw = match.group(1)
    body = text[match.end():]
    data: dict[str, Any] = {}
    current_list_key: str | None = None

    for raw_line in raw.splitlines():
        line = raw_line.rstrip()
        if not line.strip() or line.lstrip().startswith("#"):
            continue

        list_match = re.match(r"^\s*-\s+(.+?)\s*$", line)
        if list_match and current_list_key:
            data.setdefault(current_list_key, []).append(
                list_match.group(1).strip().strip("'\"")
            )
            continue

        kv = re.match(r"^([A-Za-z0-9_-]+):\s*(.*?)\s*$", line)
        if not kv:
            current_list_key = None
            continue

        key, value = kv.groups()
        if value == "":
            data[key] = []
            current_list_key = key
        elif value.startswith("[") and value.endswith("]"):
            data[key] = [
                part.strip().strip("'\"")
                for part in value[1:-1].split(",")
                if part.strip()
            ]
            current_list_key = None
        elif value.lower() in {"true", "false"}:
            data[key] = value.lower() == "true"
            current_list_key = None
        else:
            data[key] = value.strip().strip("'\"")
            current_list_key = None

    return data, body


def extract_tags(text: str, frontmatter: dict[str, Any]) -> list[str]:
    tags: set[str] = set()

    fm_tags = frontmatter.get("tags", [])
    if isinstance(fm_tags, str):
        fm_tags = fm_tags.replace(",", " ").split()

    if isinstance(fm_tags, list):
        for tag in fm_tags:
            cleaned = str(tag).strip().lstrip("#")
            if cleaned:
                tags.add(cleaned)

    without_code = re.sub(r"```.*?```", "", text, flags=re.DOTALL)

    # These are semantic markers in William's notes, not ordinary tags.
    excluded = {"q", "a", "present", "present_negative", "past", "past_negative"}

    for tag in INLINE_TAG_RE.findall(without_code):
        if tag not in excluded:
            tags.add(tag)

    return sorted(tags)


def parse_sections(body: str) -> list[dict[str, Any]]:
    lines = body.splitlines()
    sections: list[dict[str, Any]] = []
    current: dict[str, Any] | None = None
    stack: list[dict[str, Any]] = []

    def finish(end_line: int) -> None:
        nonlocal current
        if current is None:
            return
        current["line_end"] = end_line
        current["text"] = "\n".join(current.pop("_lines")).strip()
        sections.append(current)
        current = None

    for line_number, line in enumerate(lines, start=1):
        match = HEADING_RE.match(line)
        if not match:
            if current is not None:
                current["_lines"].append(line)
            continue

        level = len(match.group(1))
        heading_raw = match.group(2).strip()

        # #present:い is a property, not a heading.
        if level == 1 and re.match(r"^[A-Za-z_][A-Za-z0-9_]*\s*:", heading_raw):
            if current is not None:
                current["_lines"].append(line)
            continue

        finish(line_number - 1)

        stack = [item for item in stack if item["level"] < level]
        heading = strip_ruby(heading_raw)
        current = {
            "level": level,
            "heading": heading,
            "raw_heading": heading_raw,
            "heading_path": [item["heading"] for item in stack] + [heading],
            "line_start": line_number,
            "line_end": line_number,
            "_lines": [],
        }
        stack.append({"level": level, "heading": heading})

    finish(len(lines))
    return sections
