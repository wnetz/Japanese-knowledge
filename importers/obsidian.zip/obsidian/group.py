from __future__ import annotations

from pathlib import Path
from typing import Any

from .base import BaseNoteParser
from .models import GroupNote


class GroupParser(BaseNoteParser):
    note_type = "group"

    def parse(self, *, path: Path, raw_text: str, body: str, frontmatter: dict[str, Any]) -> GroupNote:
        common = self.build_common(path=path, raw_text=raw_text, body=body, frontmatter=frontmatter)

        groups: list[dict[str, Any]] = []
        for section in common["sections"]:
            members = [
                item for item in section.items
                if item["type"] in {"list_item", "pattern"}
            ]
            if members:
                groups.append({
                    "name": section.heading,
                    "heading_path": section.heading_path,
                    "members": members,
                })

        return GroupNote(**common, groups=groups)
