from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from .base import BaseNoteParser
from .models import LessonNote


class LessonParser(BaseNoteParser):
    note_type = "lesson"

    def parse(self, *, path: Path, raw_text: str, body: str, frontmatter: dict[str, Any]) -> LessonNote:
        common = self.build_common(path=path, raw_text=raw_text, body=body, frontmatter=frontmatter)

        lessons: list[str] = []
        questions: list[dict[str, Any]] = []
        answers: list[dict[str, Any]] = []
        patterns: list[dict[str, Any]] = []

        for section in common["sections"]:
            if section.level == 1 and re.fullmatch(r"\d+(?:-\d+)+", section.heading.strip()):
                lessons.append(section.heading.strip())

            for item in section.items:
                enriched = dict(item)
                enriched["section"] = section.heading
                enriched["heading_path"] = section.heading_path

                if item["type"] == "question":
                    questions.append(enriched)
                elif item["type"] == "answer":
                    answers.append(enriched)
                elif item["type"] == "pattern":
                    patterns.append(enriched)

        fm_lesson = str(frontmatter.get("lesson", "")).strip()
        if fm_lesson and fm_lesson not in lessons:
            lessons.insert(0, fm_lesson)

        return LessonNote(
            **common,
            lessons=lessons,
            questions=questions,
            answers=answers,
            patterns=patterns,
        )
