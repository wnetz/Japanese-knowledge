from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass
class RubyText:
    surface: str
    reading: str
    raw: str


@dataclass
class WikiLink:
    target: str
    alias: str = ""


@dataclass
class Section:
    level: int
    heading: str
    raw_heading: str
    heading_path: list[str]
    line_start: int
    line_end: int
    text: str
    items: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class BaseNote:
    note_type: str
    title: str
    filename: str
    path: str
    folder: str
    frontmatter: dict[str, Any]
    tags: list[str]
    wikilinks: list[WikiLink]
    ruby: list[RubyText]
    sections: list[Section]
    raw_text: str
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class LessonNote(BaseNote):
    lessons: list[str] = field(default_factory=list)
    questions: list[dict[str, Any]] = field(default_factory=list)
    answers: list[dict[str, Any]] = field(default_factory=list)
    patterns: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class ConjugationNote(BaseNote):
    conjugation_name: str = ""
    forms: dict[str, str] = field(default_factory=dict)
    applies_to: str = ""


@dataclass
class GroupNote(BaseNote):
    groups: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class KeyNote(BaseNote):
    key_type: str = ""
    definitions: dict[str, str] = field(default_factory=dict)


@dataclass
class ReferenceNote(BaseNote):
    pass
