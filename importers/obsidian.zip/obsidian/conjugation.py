from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from .base import BaseNoteParser
from .markdown import PROPERTY_RE, strip_ruby
from .models import ConjugationNote


class ConjugationParser(BaseNoteParser):
    note_type = "conjugation"

    def parse(self, *, path: Path, raw_text: str, body: str, frontmatter: dict[str, Any]) -> ConjugationNote:
        common = self.build_common(path=path, raw_text=raw_text, body=body, frontmatter=frontmatter)

        forms: dict[str, str] = {}
        for line in body.splitlines():
            match = PROPERTY_RE.match(line.strip())
            if match:
                key, value = match.groups()
                forms[key] = strip_ruby(value)

        conjugation_name = str(
            frontmatter.get("name")
            or frontmatter.get("conjugation_name")
            or common["title"]
        ).strip()

        applies_to = str(frontmatter.get("applies_to", "")).strip()

        return ConjugationNote(
            **common,
            conjugation_name=conjugation_name,
            forms=forms,
            applies_to=applies_to,
        )
