from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from .markdown import extract_ruby, extract_tags, extract_wikilinks, parse_sections, strip_ruby
from .models import BaseNote, RubyText, Section, WikiLink


class BaseNoteParser:
    note_type = "reference"

    def __init__(self, key_definitions: dict[str, str] | None = None) -> None:
        self.key_definitions = key_definitions or {}

    def parse(
        self,
        *,
        path: Path,
        raw_text: str,
        body: str,
        frontmatter: dict[str, Any],
    ) -> BaseNote:
        common = self.build_common(
            path=path,
            raw_text=raw_text,
            body=body,
            frontmatter=frontmatter,
        )
        return BaseNote(**common)

    def build_common(
        self,
        *,
        path: Path,
        raw_text: str,
        body: str,
        frontmatter: dict[str, Any],
    ) -> dict[str, Any]:
        section_dicts = parse_sections(body)
        sections: list[Section] = []

        for section in section_dicts:
            items = self.parse_section_items(section["text"], section["line_start"])
            sections.append(
                Section(
                    level=section["level"],
                    heading=section["heading"],
                    raw_heading=section["raw_heading"],
                    heading_path=section["heading_path"],
                    line_start=section["line_start"],
                    line_end=section["line_end"],
                    text=section["text"],
                    items=items,
                )
            )

        title = str(frontmatter.get("name") or frontmatter.get("title") or "").strip()
        if not title:
            title = self.infer_title(body, path.stem)

        return {
            "note_type": self.note_type,
            "title": title,
            "filename": path.name,
            "path": path.as_posix(),
            "folder": path.parent.as_posix(),
            "frontmatter": frontmatter,
            "tags": extract_tags(body, frontmatter),
            "wikilinks": [WikiLink(**item) for item in extract_wikilinks(body)],
            "ruby": [RubyText(**item) for item in extract_ruby(body)],
            "sections": sections,
            "raw_text": raw_text,
            "metadata": {
                "book": frontmatter.get("book", ""),
                "chapter": frontmatter.get("chapter", ""),
                "lesson": frontmatter.get("lesson", ""),
                "category": frontmatter.get("category", ""),
                "jlpt": frontmatter.get("jlpt", ""),
            },
        }

    def infer_title(self, body: str, fallback: str) -> str:
        for line in body.splitlines():
            stripped = line.strip()
            if not stripped:
                continue

            heading = re.match(r"^#{1,6}\s+(.+)$", stripped)
            if heading:
                value = heading.group(1).strip()
                if not re.match(r"^[A-Za-z_][A-Za-z0-9_]*\s*:", value):
                    return strip_ruby(value)

            if not stripped.startswith(("-", "#")):
                return strip_ruby(stripped)

        return fallback

    def parse_section_items(self, text: str, section_start_line: int) -> list[dict[str, Any]]:
        items: list[dict[str, Any]] = []

        for offset, raw_line in enumerate(text.splitlines(), start=1):
            stripped = raw_line.strip()
            if not stripped:
                continue

            line_number = section_start_line + offset
            item_type = "note"
            content = stripped

            if content.startswith("- "):
                content = content[2:].strip()
                item_type = "list_item"

            if content.startswith("#q"):
                item_type = "question"
                content = content[2:].strip()
            elif content.startswith("#a"):
                item_type = "answer"
                content = content[2:].strip()
            elif self.extract_placeholders(content):
                item_type = "pattern"

            items.append({
                "type": item_type,
                "raw": stripped,
                "text": strip_ruby(content),
                "line_number": line_number,
                "placeholders": self.extract_placeholders(content),
                "wikilinks": [x["target"] for x in extract_wikilinks(content)],
            })

        return items

    def extract_placeholders(self, text: str) -> list[str]:
        found: list[str] = []

        for symbol in sorted(self.key_definitions, key=len, reverse=True):
            if symbol in text and symbol not in found:
                found.append(symbol)

        for symbol in re.findall(r"#(?:○○|□□|■■|△|～)", text):
            if symbol not in found:
                found.append(symbol)

        return found
